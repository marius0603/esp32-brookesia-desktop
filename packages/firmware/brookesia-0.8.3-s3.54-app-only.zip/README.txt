App-only update for ESP32-S3-Touch-AMOLED-2.16.
Use tools/backup_current_firmware.py first; keep its verified private backup.
Extract this package, then run tools/update_brookesia_app_only.py with --port, --build and --backup.
The partition table is included for comparison; the updater writes only the application.
NVS, LittleFS, installed apps and SD contents are preserved.
After reboot install the matching application packages described in the release documentation.
For s3.50/s3.51 run tools/deploy_nine_grid_launcher.py before flashing, preserving original icon sizes and custom resources.
