App-only update for ESP32-S3-Touch-AMOLED-2.16.
Use tools/backup_current_firmware.py first; keep its verified private backup.
Extract this package, then run tools/update_brookesia_app_only.py with --port, --build and --backup.
The partition table is included for comparison; the updater writes only the application.
NVS, LittleFS, installed apps and SD contents are preserved.
After reboot install the matching application packages described in the release documentation.
On s3.92, run deploy_square_control_themes.py --controls-ui-only after flashing an s3.91 installation, then restart. Earlier releases also need the matching s3.91 resources.
For an upgrade from s3.87, deploy the Controls resources with tools/deploy_square_control_themes.py --controls-ui-only, then restart.
For a first installation of the square desktop run tools/deploy_square_control_themes.py over USB after flashing, then reboot to load the desktop and Controls resources.
