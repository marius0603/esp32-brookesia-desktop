App-only update for ESP32-S3-Touch-AMOLED-2.16.
Use tools/backup_current_firmware.py first; keep its verified private backup.
Extract this package, then run tools/update_brookesia_app_only.py with --port, --build and --backup.
The partition table is included for comparison; the updater writes only the application.
NVS, LittleFS, installed apps and SD contents are preserved.
After reboot install the matching application packages described in the release documentation.
Before updating from s3.27 or earlier, run tools/deploy_phone_launcher.py to install the matching launcher document.
launcher/app_launcher.json is a separate filesystem resource, not a Flash partition image.
s3.28 and s3.29 share the same launcher document; s3.28 upgrades need only the application partition.
