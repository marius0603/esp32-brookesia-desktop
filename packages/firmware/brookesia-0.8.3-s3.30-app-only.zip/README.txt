App-only update for ESP32-S3-Touch-AMOLED-2.16.
Use tools/backup_current_firmware.py first; keep its verified private backup.
Extract this package, then run tools/update_brookesia_app_only.py with --port, --build and --backup.
The partition table is included for comparison; the updater writes only the application.
NVS, LittleFS, installed apps and SD contents are preserved.
After reboot install the matching application packages described in the release documentation.
Before updating to s3.30, run tools/deploy_phone_launcher.py to install the native-scroll launcher document.
launcher/app_launcher.json is a separate filesystem resource, not a Flash partition image.
s3.28 and s3.29 share the earlier document; restoring those versions also requires restoring that document.
