Cyberpunk desktop theme 1.0.0 for s3.31.
Use tools/deploy_desktop_themes.py from this repository; restart to load images and fonts.
Settings > Display > Desktop theme: Q / Cyberpunk.
Artwork is preloaded into RAM. Missing SD assets fall back to the original Q artwork.
