Transparent Q launcher resources 1.1.0 for firmware s3.40.
Use tools/deploy_transparent_icons.py from the matching repository, then restart.
RGB565A8 keeps source alpha instead of baking a rectangular matte.
Preserves apps, stories, volume and wallpaper.
Original image indexes are backed up privately and on SD for rollback.
