Optimized Q launcher resources 1.0.0 for firmware s3.30.
Use tools/deploy_launcher_cache.py from the matching repository, then restart.
Preserves apps, stories and volume; backs up original launcher resources privately.
Restore with --restore <first backup folder>, then restart.
